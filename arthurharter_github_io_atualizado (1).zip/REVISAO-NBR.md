# Revisão dos valores — ABNT NBR 5410:2004 (2ª ed.), Versão Corrigida:2008

Fonte única: **Tabela 36** — capacidades de condução de corrente (A), cobre, isolação PVC, 70 °C, ambiente 30 °C, **método B1**, colunas de 2 e 3 condutores carregados. Valores lidos do PDF enviado (Versão Corrigida de 17.03.2008).

Texto citado no site: “Valores conforme ABNT NBR 5410:2004, Versão Corrigida:2008, Tabela 36 (método B1, PVC, 2 condutores carregados).”

## 1. Capacidade de condução (Iz) — tabelas e scripts do site

| Arquivo / tabela | Seção | Valor antes | Valor conforme a norma | Origem | Situação |
|---|---|---|---|---|---|
| bitola-de-fios.html — tabela principal | 1,5 | 17,5 / 15,5 | 17,5 / 15,5 | Tabela 36, B1 | OK |
|  | 2,5 | 24 / 21 | 24 / 21 | Tabela 36, B1 | OK |
|  | 4 | 32 / 28 | 32 / 28 | Tabela 36, B1 | OK |
|  | 6 | 41 / 36 | 41 / 36 | Tabela 36, B1 | OK |
|  | 10 | 57 / 50 | 57 / 50 | Tabela 36, B1 | OK |
|  | 16 | 76 / 68 | 76 / 68 | Tabela 36, B1 | OK |
|  | 25 | 101 / 89 | 101 / 89 | Tabela 36, B1 | OK |
|  | 35 | 125 / **111** | 125 / **110** | Tabela 36, B1 | **Corrigido** (3 condutores: 111 → 110) |
|  | 50 | 151 / 134 | 151 / 134 | Tabela 36, B1 | OK |
| calculadora-bitola-cabo.html — vetor `c2`/`c3` | 1,5 a 95 | conforme o site | idem Tabela 36 | Tabela 36, B1 | 35 mm², 3 cond.: 111 → 110 (corrigido); demais OK |
| calculadora-disjuntor.html — vetor `iz` | 1,5 a 95 | conforme o site | idem Tabela 36 (2 cond.) | Tabela 36, B1 | OK (11 valores conferidos) |
| fio-e-disjuntor-ar-condicionado-12000-btu.html — `tab` | 1,5 a 95 | conforme o site | idem Tabela 36 (2 cond.) | Tabela 36, B1 | OK |
| fio-e-disjuntor-chuveiro-5500w.html — `tab` | 1,5 a 95 | conforme o site | idem Tabela 36 (2 cond.) | Tabela 36, B1 | OK |
| index.html — mini-tabela de bitolas | 1,5 | 15 A | 17,5 A (2 cond.) | Tabela 36, B1 | **Corrigido** |
|  | 2,5 | 21 A | 24 A (2 cond.) | Tabela 36, B1 | **Corrigido** |
|  | 4 | 32 A | 32 A | Tabela 36, B1 | OK |
|  | 6 | 41 A | 41 A | Tabela 36, B1 | OK |
|  | 10 | 50 A | 57 A (2 cond.) | Tabela 36, B1 | **Corrigido** |

Observação: as colunas de “Pot. 127 V / 220 V” da bitola-de-fios.html usam a coluna de 2 condutores (ex.: 125 A × 127 V = 15.875 W); conferido.

## 2. Tabelas de disjuntor — regra Ib ≤ In ≤ Iz

Iz = Tabela 36, B1, 2 condutores, da seção de fio indicada em cada linha. Páginas conferidas: index, disjuntores, ar-condicionado, chuveiro-eletrico, carregador-veiculo-eletrico, energia-solar, torneira-eletrica, fio-e-disjuntor-chuveiro-5500w.

**Linhas que violam a regra: nenhuma.**

Casos-limite (In = Iz; a regra permite a igualdade, mas sem folga):

| Página | Ib (A) | In (A) | Fio | Iz (A) |
|---|---|---|---|---|
| index.html — chuveiro 6.000 W | 27 | 32 | 4 mm² | 32 |
| disjuntores.html — chuveiro | 25 | 32 | 4 mm² | 32 |
| chuveiro-eletrico.html | 25 | 32 | 4 mm² | 32 |
| torneira-eletrica.html | 25,2 / 25 | 32 | 4 mm² | 32 |

Nota: a conferência só usa a Tabela 36. Fatores de correção (agrupamento, temperatura) e as demais condições de proteção contra sobrecarga da norma não foram avaliados.

## 3. Correntes dos equipamentos (220 V)

Conferido potência ÷ 220 V em index.html e disjuntores.html: todas as linhas batem (arredondamento de até 0,2 A, ex.: 6.000 W → 27,3 A mostrado como 27 A; 4.000 W → 18,2 A mostrado como 18 A).

## 4. Texto sobre tensão

O pedido sugeria “em 127 V as correntes são aproximadamente o dobro”. A razão exata é 220 ÷ 127 ≈ **1,73**, e as tabelas do site mostram isso (chuveiro 5.500 W: 25 A em 220 V, 43,3 A em 127 V). O texto publicado diz “cerca de 1,7 vez maiores”.
